# Film institutionnel — Lutte contre les cancers féminins au Tchad

Remotion 4 · React · TypeScript · SVG · Lucide. 1920×1080, 30 FPS, 210 s (6 300 images).

## Démarrage
```bash
npm install
npm start          # Remotion Studio (prévisualisation)
npm run build      # export MP4 H.264 -> out/film-cancers-feminins-tchad.mp4
```
Si npm signale une incohérence de versions Remotion : `npx remotion upgrade`.

Dans le Studio : la composition `MainVideo` (film complet) et une composition par scène (`S1-Constat` … `S10-Final`).

## Structure
- `src/theme.ts` : couleurs, polices, réglages audio (`AUDIO`) et logos (`LOGOS`).
- `src/scenes/` : les 9 scènes + la scène finale ; `index.ts` = durées (somme = 210 s).
- `src/illustrations/` : personnages SVG (femmes, soignants), bâtiments, cartes (Tchad, Afrique), ruban rose.
- `src/components/` : textes animés, compteurs, décor, transitions.
- `src/MainVideo.tsx` : montage, transitions « balayage », pistes audio.

## Voix off et musique
Déposez `voix-off.mp3` et `musique-fond.mp3` dans `public/audio/`, puis `AUDIO.musicEnabled = true`.

## Logos officiels
Aucun logo n'est inventé : deux cadres réservés sont affichés dans la scène finale. Placez les fichiers fournis par le Ministère dans `public/logos/` et renseignez `LOGOS`.

## Données
Seuls les chiffres du brief sont utilisés (5 426 · 2 636 · 10 · 5 · 320 · 110 · 24 000 · 4 300 · VIH ×6 · 2023 · 2027). Les cartes sont stylisées (non cartométriques).
