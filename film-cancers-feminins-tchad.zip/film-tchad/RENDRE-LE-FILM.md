# Obtenir le MP4

1. Installer Node.js 18+ (https://nodejs.org)
2. Dans ce dossier :
   npm install
   npm run build
3. Le fichier est créé ici : out/film-cancers-feminins-tchad.mp4 (1920x1080, 30 fps, H.264, ~3 min 30)

Premier rendu : Remotion télécharge Chrome Headless automatiquement (connexion Internet requise). Comptez quelques minutes à plus d'une dizaine selon la machine.
