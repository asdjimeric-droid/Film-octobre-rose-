import React from 'react';
import {useEnter} from '../anim';

export const Reveal: React.FC<{
  delay?: number;
  x?: number;
  y?: number;
  scale?: number;
  bounce?: boolean;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({delay = 0, x = 0, y = 30, scale = 1, bounce = false, style, children}) => {
  const s = useEnter(delay, bounce ? 11 : 200, bounce ? 40 : 32);
  const sc = scale + (1 - scale) * s;
  return (
    <div
      style={{
        opacity: Math.min(1, s * 1.4),
        transform: `translate(${(1 - s) * x}px, ${(1 - s) * y}px) scale(${sc})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};
