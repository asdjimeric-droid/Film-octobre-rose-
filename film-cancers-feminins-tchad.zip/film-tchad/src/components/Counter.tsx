import React from 'react';
import {Easing, useCurrentFrame} from 'remotion';
import {range} from '../anim';
import {C, FONT_SERIF} from '../theme';

export const fmt = (n: number) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');

// Compteur animé (séparateur de milliers français).
export const Counter: React.FC<{
  to: number;
  delay?: number;
  duration?: number;
  size?: number;
  color?: string;
  prefix?: string;
  suffix?: string;
  style?: React.CSSProperties;
}> = ({to, delay = 0, duration = 90, size = 140, color = C.white, prefix = '', suffix = '', style}) => {
  const frame = useCurrentFrame();
  const p = range(frame, delay, delay + duration, 0, 1, Easing.out(Easing.cubic));
  const visible = frame >= delay - 6;
  return (
    <span
      style={{
        fontFamily: FONT_SERIF, fontSize: size, fontWeight: 800, color, lineHeight: 1,
        fontVariantNumeric: 'tabular-nums', opacity: visible ? 1 : 0, whiteSpace: 'nowrap', ...style,
      }}
    >
      {prefix}{fmt(Math.round(to * p))}{suffix}
    </span>
  );
};
