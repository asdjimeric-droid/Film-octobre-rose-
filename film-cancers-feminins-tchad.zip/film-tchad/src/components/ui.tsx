import React from 'react';
import {useCurrentFrame} from 'remotion';
import type {LucideIcon} from 'lucide-react';
import {C, FONT_SANS} from '../theme';
import {Counter} from './Counter';
import {Reveal} from './Reveal';

export const Chip: React.FC<{children: React.ReactNode; color?: string; size?: number}> = ({children, color = C.pink, size = 28}) => (
  <div style={{padding: '14px 30px', borderRadius: 40, background: color, color: C.white, fontSize: size, fontWeight: 600, fontFamily: FONT_SANS, boxShadow: '0 10px 30px rgba(232,62,140,.3)'}}>
    {children}
  </div>
);

export const Stat: React.FC<{to: number; label: string; delay?: number; color?: string; size?: number; duration?: number}> = ({
  to, label, delay = 0, color = C.white, size = 150, duration = 90,
}) => (
  <div>
    <Counter to={to} delay={delay} duration={duration} size={size} color={color} />
    <Reveal delay={delay + 14} y={16}>
      <div style={{fontSize: 32, color: C.soft, marginTop: 8, fontFamily: FONT_SANS}}>{label}</div>
    </Reveal>
  </div>
);

export const GlassCard: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div style={{background: 'linear-gradient(160deg, rgba(255,255,255,.10), rgba(255,255,255,.03))', border: '1px solid rgba(212,175,55,.38)', borderRadius: 30, boxShadow: '0 24px 60px rgba(0,0,0,.28)', ...style}}>
    {children}
  </div>
);

export const IconBadge: React.FC<{icon: LucideIcon; size?: number; color?: string; bg?: string}> = ({icon: Icon, size = 120, color = C.white, bg = C.pink}) => (
  <div style={{width: size, height: size, borderRadius: '50%', background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 14px 34px rgba(0,0,0,.35)', border: `3px solid ${C.gold}`}}>
    <Icon size={size * 0.48} color={color} strokeWidth={2} />
  </div>
);

// Icônes en orbite autour d'un centre (HTML absolu, parent en position: relative).
export const Orbit: React.FC<{icons: LucideIcon[]; radius: number; center: number; size?: number; speed?: number}> = ({icons, radius, center, size = 96, speed = 0.35}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {icons.map((Icon, i) => {
        const a = ((frame * speed + (360 / icons.length) * i) * Math.PI) / 180;
        return (
          <div key={i} style={{position: 'absolute', left: center + Math.cos(a) * radius - size / 2, top: center + Math.sin(a) * radius - size / 2}}>
            <IconBadge icon={Icon} size={size} bg={i % 2 ? C.navy2 : C.pink} />
          </div>
        );
      })}
    </>
  );
};
