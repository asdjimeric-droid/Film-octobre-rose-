import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, FONT_SANS, FONT_SERIF, FONT_SERIF_ITALIC} from '../theme';

// Révélation mot par mot (masque + glissement vertical).
export const AnimatedText: React.FC<{
  text: string;
  size?: number;
  color?: string;
  font?: 'sans' | 'serif' | 'italic';
  weight?: number;
  delay?: number;
  stagger?: number;
  align?: 'left' | 'center';
  lineHeight?: number;
  maxWidth?: number;
  accentWords?: string[];
  accent?: string;
  style?: React.CSSProperties;
}> = ({
  text, size = 60, color = C.white, font = 'sans', weight = 800, delay = 0, stagger = 5,
  align = 'left', lineHeight = 1.12, maxWidth, accentWords = [], accent = C.pink, style,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  let k = 0;
  const family = font === 'serif' ? FONT_SERIF : font === 'italic' ? FONT_SERIF_ITALIC : FONT_SANS;
  return (
    <div style={{fontFamily: family, fontSize: size, fontWeight: weight, color, lineHeight, maxWidth, textAlign: align, ...style}}>
      {text.split('\n').map((line, li) => (
        <div
          key={li}
          style={{display: 'flex', flexWrap: 'wrap', justifyContent: align === 'center' ? 'center' : 'flex-start', columnGap: size * 0.26}}
        >
          {line.split(' ').map((w, wi) => {
            const s = spring({frame: frame - delay - k++ * stagger, fps, config: {damping: 200}, durationInFrames: 30});
            const isAccent = accentWords.includes(w.replace(/[.,]/g, ''));
            return (
              <span key={wi} style={{display: 'inline-block', overflow: 'hidden', paddingBottom: size * 0.16, marginBottom: -size * 0.16}}>
                <span style={{display: 'inline-block', transform: `translateY(${(1 - s) * 108}%)`, opacity: s, color: isAccent ? accent : undefined}}>
                  {w}
                </span>
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};
