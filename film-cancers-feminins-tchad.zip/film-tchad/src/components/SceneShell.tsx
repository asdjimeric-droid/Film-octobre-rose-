import React from 'react';
import {AbsoluteFill, Sequence, interpolate, random, useCurrentFrame} from 'remotion';
import {clamp, range} from '../anim';
import {C, FONT_SANS} from '../theme';

const Cells: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      {Array.from({length: 16}).map((_, i) => {
        const x = random('x' + i) * 1920;
        const y = random('y' + i) * 1080;
        const r = 24 + random('r' + i) * 80;
        const dy = Math.sin((frame + i * 37) / 80) * 22;
        const dx = Math.cos((frame + i * 53) / 110) * 16;
        return (
          <div
            key={i}
            style={{
              position: 'absolute', left: x + dx - r, top: y + dy - r, width: r * 2, height: r * 2, borderRadius: '50%',
              background: i % 3 === 0 ? 'rgba(232,62,140,.07)' : 'rgba(255,255,255,.035)',
              border: i % 4 === 0 ? '1px solid rgba(212,175,55,.18)' : 'none',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

export const SceneShell: React.FC<{n: number; title: string; duration: number; children: React.ReactNode}> = ({n, title, duration, children}) => {
  const frame = useCurrentFrame();
  const out = interpolate(frame, [duration - 10, duration], [1, 0], clamp);
  const zoom = interpolate(frame, [0, duration], [1, 1.035], clamp);
  const line = range(frame, 12, 60);
  const label = n <= 9 ? `0${n} / 09` : 'FINAL';
  return (
    <AbsoluteFill
      style={{
        fontFamily: FONT_SANS, opacity: out, overflow: 'hidden',
        background: `radial-gradient(1400px 900px at 80% 8%, ${C.navy2} 0%, ${C.navy} 55%, #0A1B2D 100%)`,
      }}
    >
      <Cells />
      <AbsoluteFill style={{transform: `scale(${zoom})`}}>
        <Sequence from={12} layout="none">{children}</Sequence>
      </AbsoluteFill>
      <div style={{position: 'absolute', left: 100, top: 52, display: 'flex', alignItems: 'center', gap: 22}}>
        <span style={{color: C.gold, fontWeight: 800, fontSize: 24, letterSpacing: 3}}>{label}</span>
        <div style={{width: 140 * line, height: 3, background: C.gold}} />
        <span style={{color: '#9FB3C8', fontWeight: 600, fontSize: 22, letterSpacing: 4, opacity: line}}>{title.toUpperCase()}</span>
      </div>
      <div style={{position: 'absolute', left: 100, bottom: 38, color: '#7F94AA', fontSize: 18, letterSpacing: 2}}>
        Lutte contre les cancers féminins au Tchad
      </div>
      <div style={{position: 'absolute', right: 100, bottom: 44, display: 'flex', gap: 10}}>
        {Array.from({length: 10}).map((_, i) => (
          <div key={i} style={{width: i + 1 === n ? 34 : 10, height: 10, borderRadius: 5, background: i + 1 === n ? C.pink : 'rgba(255,255,255,.22)'}} />
        ))}
      </div>
    </AbsoluteFill>
  );
};
