import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {clamp} from '../anim';
import {C} from '../theme';
import {Ribbon} from '../illustrations/Figures';

// Balayage cinématographique de 30 images : or, rose, bleu nuit. Plein écran à l'image 15.
export const Wipe: React.FC<{variant: number}> = ({variant}) => {
  const f = useCurrentFrame();
  const dir = variant % 2 === 0 ? 1 : -1;
  const layer = (delay: number, color: string) => {
    const p = interpolate(f, [delay, delay + 26], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
    const x = interpolate(p, [0, 1], [-125, 125]) * dir;
    return (
      <AbsoluteFill key={color} style={{left: '-12%', width: '124%', background: color, transform: `translateX(${x}%) skewX(${-14 * dir}deg)`}} />
    );
  };
  return (
    <AbsoluteFill>
      {layer(0, C.gold)}
      {layer(2, C.pink)}
      {layer(4, C.navy)}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', opacity: interpolate(f, [9, 15, 21], [0, 1, 0], clamp)}}>
        <Ribbon size={140} color={C.white} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
