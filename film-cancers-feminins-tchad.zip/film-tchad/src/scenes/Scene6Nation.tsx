import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Building2, Globe, GraduationCap, HeartHandshake, Landmark, Newspaper, Users} from 'lucide-react';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {IconBadge} from '../components/ui';
import {range} from '../anim';
import {C, FONT_SANS} from '../theme';
import {HealthPro, Ribbon, Woman} from '../illustrations/Figures';

const GROUPS = [
  {icon: Landmark, label: 'Institutions nationales\net ministères'},
  {icon: GraduationCap, label: 'Écoles\net universités'},
  {icon: Building2, label: 'Entreprises\net secteur privé'},
  {icon: HeartHandshake, label: 'Associations et\nsociété civile'},
  {icon: Users, label: 'Leaders religieux\net traditionnels'},
  {icon: Newspaper, label: 'Médias\net artistes'},
  {icon: Globe, label: 'Organisations\ninternationales'},
];
const CX = 960, CY = 590, RX = 650, RY = 320;

export const Scene6Nation: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const pos = GROUPS.map((_, i) => {
    const a = ((-90 + (360 / GROUPS.length) * i) * Math.PI) / 180;
    return {x: CX + Math.cos(a) * RX, y: CY + Math.sin(a) * RY};
  });
  return (
    <SceneShell n={6} title="Toute la nation se mobilise" duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 100, top: 150}}>
          <AnimatedText text={"Toute la nation\nse mobilise"} size={62} font="serif" accentWords={['mobilise']} />
        </div>
        <svg width="1920" height="1080" style={{position: 'absolute', inset: 0}}>
          {pos.map((p, i) => {
            const t = range(frame, 110 + i * 55, 150 + i * 55);
            return <line key={i} x1={CX} y1={CY} x2={p.x} y2={p.y} stroke={C.gold} strokeWidth="2.5" strokeDasharray="8 8" opacity={0.7 * t} />;
          })}
          <circle cx={CX} cy={CY} r={200 + Math.sin(frame / 20) * 6} fill="rgba(232,62,140,.16)" stroke={C.pink} strokeWidth="3" />
        </svg>
        <Reveal delay={30} scale={0.7} y={0} style={{position: 'absolute', left: CX - 230, top: CY - 190}}>
          <div style={{position: 'relative', width: 460, height: 380}}>
            <div style={{position: 'absolute', left: 0, top: 70}}><Woman size={300} wrap={C.gold} dress={C.pink} accent={C.white} /></div>
            <div style={{position: 'absolute', left: 150, top: 60}}><HealthPro size={310} /></div>
            <div style={{position: 'absolute', left: 290, top: 80}}><Woman size={290} skin="#4A2E20" wrap="#2E8B6E" dress={C.white} armUp /></div>
            <div style={{position: 'absolute', left: 170, top: -30}}><Ribbon size={100} /></div>
          </div>
        </Reveal>
        {GROUPS.map((g, i) => (
          <Reveal key={i} delay={100 + i * 55} bounce scale={0.4} y={0} style={{position: 'absolute', left: pos[i].x - 190, top: pos[i].y - 60, width: 380}}>
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
              <IconBadge icon={g.icon} size={116} bg={i % 2 ? C.navy2 : C.pink} />
              <div style={{marginTop: 12, fontFamily: FONT_SANS, fontSize: 26, fontWeight: 600, textAlign: 'center', whiteSpace: 'pre-line', lineHeight: 1.25, color: C.white, textShadow: '0 2px 12px rgba(0,0,0,.6)'}}>{g.label}</div>
            </div>
          </Reveal>
        ))}
      </AbsoluteFill>
    </SceneShell>
  );
};
