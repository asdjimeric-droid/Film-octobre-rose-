import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Activity, Dna, Microscope, Stethoscope} from 'lucide-react';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {Chip, Orbit, Stat} from '../components/ui';
import {range} from '../anim';
import {C} from '../theme';
import {HealthPro, Ribbon, Woman} from '../illustrations/Figures';

export const Scene1Constat: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const bar = range(frame, 330, 420);
  return (
    <SceneShell n={1} title="Le constat" duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 100, top: 170, width: 1000}}>
          <AnimatedText text={"Registre des cancers\nde N'Djaména"} size={78} font="serif" accentWords={["N'Djaména"]} />
          <Reveal delay={50} style={{marginTop: 18}}>
            <div style={{color: C.gold, fontSize: 32, letterSpacing: 6, fontWeight: 600}}>2022 – 2025</div>
          </Reveal>
          <div style={{display: 'flex', gap: 90, marginTop: 56}}>
            <Stat to={5426} label="cas enregistrés" delay={100} />
            <Stat to={2636} label="cas chez les femmes" delay={230} color={C.pink} />
          </div>
          <Reveal delay={320} style={{marginTop: 34}}>
            <div style={{width: 900, height: 14, borderRadius: 7, background: 'rgba(255,255,255,.15)', overflow: 'hidden'}}>
              <div style={{width: `${(2636 / 5426) * 100 * bar}%`, height: '100%', background: `linear-gradient(90deg, ${C.pink}, #ff86c0)`}} />
            </div>
          </Reveal>
          <Reveal delay={440} style={{marginTop: 54}}>
            <div style={{color: C.soft, fontSize: 30, marginBottom: 20}}>Cancers féminins les plus fréquents</div>
            <div style={{display: 'flex', gap: 20}}>
              <Chip>Cancer du sein</Chip>
              <Chip>Cancer du col de l'utérus</Chip>
            </div>
          </Reveal>
        </div>
        <div style={{position: 'absolute', left: 1080, top: 190, width: 740, height: 740}}>
          <Reveal delay={20} scale={0.8} y={0} style={{position: 'absolute', inset: 0}}>
            <svg width="740" height="740" viewBox="0 0 740 740">
              <circle cx="370" cy="370" r="330" fill="none" stroke={C.gold} strokeWidth="2" strokeDasharray="4 12" opacity=".7" />
              <circle cx="370" cy="370" r="250" fill="rgba(232,62,140,.14)" stroke="rgba(232,62,140,.5)" strokeWidth="2" />
            </svg>
            <div style={{position: 'absolute', left: 190, top: 250}}><Woman size={380} /></div>
            <div style={{position: 'absolute', left: 340, top: 250}}><HealthPro size={380} scrub={C.navy2} /></div>
            <div style={{position: 'absolute', left: 300, top: 120}}><Ribbon size={140} /></div>
            <Orbit icons={[Microscope, Dna, Stethoscope, Activity]} radius={330} center={370} />
          </Reveal>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
