import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {CalendarCheck, ShieldCheck, Stethoscope} from 'lucide-react';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {GlassCard} from '../components/ui';
import {range} from '../anim';
import {C, FONT_SERIF} from '../theme';
import {Clinic} from '../illustrations/Buildings';
import {HealthPro, Woman} from '../illustrations/Figures';

const MONTHS = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];

export const Scene2Reponse: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const rise = range(frame, 20, 140);
  return (
    <SceneShell n={2} title="La réponse" duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 80, top: 250}}>
          <Clinic p={rise} width={900} />
          <div style={{position: 'absolute', left: 270, top: 390, opacity: range(frame, 150, 190)}}><Woman size={230} /></div>
          <div style={{position: 'absolute', left: 430, top: 390, opacity: range(frame, 170, 210)}}><HealthPro size={230} /></div>
        </div>
        <div style={{position: 'absolute', left: 1040, top: 170, width: 790}}>
          <AnimatedText text="Une unité dédiée au dépistage" size={64} font="serif" accentWords={['dépistage']} />
          <Reveal delay={70} style={{marginTop: 26}}>
            <div style={{fontFamily: FONT_SERIF, fontSize: 70, fontWeight: 800, color: C.gold}}>Octobre 2023</div>
          </Reveal>
          <Reveal delay={110} style={{marginTop: 14}}>
            <div style={{fontSize: 34, lineHeight: 1.35, color: C.white}}>
              Création de l'Unité de dépistage des cancers du sein et du col de l'utérus.
            </div>
          </Reveal>
          <div style={{display: 'flex', flexDirection: 'column', gap: 18, marginTop: 40}}>
            {[
              {i: ShieldCheck, t: 'Dépistage gratuit', d: 230},
              {i: Stethoscope, t: 'Traitement des lésions', d: 290},
            ].map(({i: Icon, t, d}) => (
              <Reveal key={t} delay={d} x={60} y={0}>
                <GlassCard style={{display: 'flex', alignItems: 'center', gap: 22, padding: '20px 30px'}}>
                  <Icon size={44} color={C.pink} />
                  <span style={{fontSize: 36, fontWeight: 600}}>{t}</span>
                </GlassCard>
              </Reveal>
            ))}
          </div>
          <Reveal delay={360} style={{marginTop: 34}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 14, color: C.soft, fontSize: 30, marginBottom: 16}}>
              <CalendarCheck size={34} color={C.gold} /> Tout au long de l'année
            </div>
          </Reveal>
          <div style={{display: 'flex', gap: 10}}>
            {MONTHS.map((m, i) => {
              const on = range(frame, 380 + i * 12, 396 + i * 12);
              return (
                <div key={i} style={{width: 52, height: 52, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 22, color: C.white, background: `rgba(232,62,140,${0.15 + 0.85 * on})`, border: `2px solid ${C.gold}`}}>
                  {m}
                </div>
              );
            })}
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
