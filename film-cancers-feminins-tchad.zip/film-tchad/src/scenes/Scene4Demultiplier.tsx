import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {Counter} from '../components/Counter';
import {GlassCard} from '../components/ui';
import {C, FONT_SANS} from '../theme';
import {HealthPro, ImageBox, Woman} from '../illustrations/Figures';

const Ripples: React.FC<{i: number}> = ({i}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {[0, 1].map((k) => {
        const t = ((frame + i * 25 + k * 45) % 90) / 90;
        return (
          <div key={k} style={{position: 'absolute', left: '50%', top: 150, width: 260 + t * 280, height: 260 + t * 280, marginLeft: -(130 + t * 140), marginTop: -(130 + t * 140), borderRadius: '50%', border: `2px solid ${C.pink}`, opacity: (1 - t) * 0.5}} />
        );
      })}
    </>
  );
};

export const Scene4Demultiplier: React.FC<{duration: number}> = ({duration}) => (
  <SceneShell n={4} title="Démultiplier les compétences" duration={duration}>
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 100, top: 160}}>
        <AnimatedText text="Démultiplier les compétences" size={72} font="serif" accentWords={['compétences']} />
      </div>
      {[
        {x: 100, d: 90},
        {x: 700, d: 210},
        {x: 1300, d: 330},
      ].map(({x, d}, i) => (
        <Reveal key={i} delay={d} y={60} style={{position: 'absolute', left: x, top: 330, width: 520}}>
          <GlassCard style={{height: 650, overflow: 'hidden', position: 'relative'}}>
            <Ripples i={i} />
            <div style={{position: 'absolute', left: 0, right: 0, top: 30, display: 'flex', justifyContent: 'center'}}>
              {i === 0 && <HealthPro size={290} />}
              {i === 1 && <HealthPro size={290} male scrub={C.navy2} skin="#4A2E20" />}
              {i === 2 && (
                <div style={{display: 'flex', alignItems: 'flex-end', gap: 0}}>
                  <Woman size={290} wrap={C.gold} dress={C.pink} accent={C.white} armUp />
                  <ImageBox size={180} style={{marginLeft: -20}} />
                </div>
              )}
            </div>
            <div style={{position: 'absolute', left: 36, right: 36, top: 350, fontFamily: FONT_SANS}}>
              {i === 0 && (<><Counter to={320} delay={d + 20} duration={90} size={130} color={C.pink} /><div style={{fontSize: 34, color: C.white, marginTop: 10}}>sages-femmes formées</div></>)}
              {i === 1 && (<><Counter to={110} delay={d + 20} duration={80} size={130} color={C.gold} /><div style={{fontSize: 34, color: C.white, marginTop: 10}}>médecins formés</div></>)}
              {i === 2 && (<><div style={{fontSize: 44, fontWeight: 800, color: C.pink, lineHeight: 1.15}}>Agents de santé communautaire</div><div style={{fontSize: 32, color: C.white, marginTop: 14, lineHeight: 1.3}}>formés avec des boîtes à images</div></>)}
            </div>
          </GlassCard>
        </Reveal>
      ))}
    </AbsoluteFill>
  </SceneShell>
);
