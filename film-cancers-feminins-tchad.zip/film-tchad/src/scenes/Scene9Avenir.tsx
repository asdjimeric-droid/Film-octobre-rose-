import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Syringe} from 'lucide-react';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {GlassCard} from '../components/ui';
import {range, useEnter} from '../anim';
import {C, FONT_SANS, FONT_SERIF} from '../theme';
import {CancerCenter} from '../illustrations/Buildings';

export const Scene9Avenir: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const build = range(frame, 30, 260);
  const shield = useEnter(330, 12, 40);
  const syr = range(frame, 380, 450);
  return (
    <SceneShell n={9} title="L'avenir" duration={duration}>
      <AbsoluteFill style={{fontFamily: FONT_SANS}}>
        <div style={{position: 'absolute', left: 100, top: 160}}>
          <AnimatedText text="Préparer l'avenir" size={72} font="serif" accentWords={["l'avenir"]} />
        </div>
        <div style={{position: 'absolute', left: 60, top: 300}}>
          <CancerCenter p={build} width={900} />
        </div>
        <div style={{position: 'absolute', left: 100, top: 810, width: 860}}>
          <Reveal delay={90}><div style={{fontSize: 36, fontWeight: 800, color: C.gold}}>CNEC · Centre National d'Excellence en Cancérologie</div></Reveal>
          <Reveal delay={190} style={{marginTop: 12}}><div style={{fontSize: 30, color: C.white, lineHeight: 1.4}}>Conception achevée. Mobilisation imminente du site.</div></Reveal>
        </div>
        <div style={{position: 'absolute', left: 1040, top: 260, width: 780}}>
          <GlassCard style={{padding: '40px 44px', height: 700, position: 'relative', overflow: 'hidden'}}>
            {[0, 1, 2].map((k) => {
              const t = ((frame - 330 + k * 40) % 120) / 120;
              return <div key={k} style={{position: 'absolute', left: 390 - (140 + t * 230), top: 300 - (140 + t * 230), width: 280 + t * 460, height: 280 + t * 460, borderRadius: '50%', border: `2px solid ${C.pink}`, opacity: frame > 340 ? (1 - t) * 0.55 : 0}} />;
            })}
            <div style={{position: 'absolute', left: 190, top: 120, transform: `scale(${shield})`, opacity: shield}}>
              <svg viewBox="0 0 400 400" width="400" height="400">
                <path d="M200 20 L340 70 L340 190 C340 280 280 340 200 380 C120 340 60 280 60 190 L60 70 Z" fill="rgba(232,62,140,.28)" stroke={C.pink} strokeWidth="6" />
                <path d="M130 200 L180 250 L275 145" fill="none" stroke={C.white} strokeWidth="18" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div style={{position: 'absolute', left: 470 - (1 - syr) * 160, top: 110 + (1 - syr) * 120, opacity: syr, transform: 'rotate(-35deg)'}}>
              <Syringe size={150} color={C.gold} strokeWidth={2} />
            </div>
            <div style={{position: 'absolute', left: 44, right: 44, bottom: 40, textAlign: 'center'}}>
              <Reveal delay={470}><div style={{fontSize: 32, color: C.soft}}>Introduction prévue du vaccin anti-HPV en</div></Reveal>
              <Reveal delay={500} bounce scale={0.6} y={0}><div style={{fontFamily: FONT_SERIF, fontSize: 130, fontWeight: 800, color: C.pink, lineHeight: 1.05}}>2027</div></Reveal>
            </div>
          </GlassCard>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
