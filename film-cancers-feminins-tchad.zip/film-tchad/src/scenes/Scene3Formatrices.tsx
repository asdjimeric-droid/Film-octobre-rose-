import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {GlassCard, Stat} from '../components/ui';
import {range} from '../anim';
import {C} from '../theme';
import {AfricaMap} from '../illustrations/Maps';
import {HealthPro} from '../illustrations/Figures';

export const Scene3Formatrices: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const reveal = range(frame, 0, 70);
  const pBf = range(frame, 90, 170);
  const pSn = range(frame, 250, 330);
  const loop = (frame % 120) / 120;
  return (
    <SceneShell n={3} title="Former des formatrices" duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 100, top: 170, width: 880}}>
          <AnimatedText text={"Former des\nformatrices"} size={80} font="serif" accentWords={['formatrices']} />
          <Reveal delay={150} style={{marginTop: 50}}>
            <GlassCard style={{padding: '26px 36px', display: 'flex', alignItems: 'center', gap: 30}}>
              <HealthPro size={170} scrub={C.pink} />
              <Stat to={10} size={120} delay={160} duration={50} color={C.pink} label="sages-femmes formées au Burkina Faso" />
            </GlassCard>
          </Reveal>
          <Reveal delay={310} style={{marginTop: 30}}>
            <GlassCard style={{padding: '26px 36px', display: 'flex', alignItems: 'center', gap: 30}}>
              <HealthPro size={170} scrub={C.gold} skin="#4A2E20" />
              <Stat to={5} size={120} delay={320} duration={40} color={C.gold} label="sages-femmes en formation au Sénégal" />
            </GlassCard>
          </Reveal>
        </div>
        <div style={{position: 'absolute', left: 980, top: 150}}>
          <AfricaMap reveal={reveal} pBf={pBf} pSn={pSn} loop={loop} width={860} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
