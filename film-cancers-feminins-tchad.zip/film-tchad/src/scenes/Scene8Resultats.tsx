import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {SceneShell} from '../components/SceneShell';
import {Counter} from '../components/Counter';
import {Reveal} from '../components/Reveal';
import {range} from '../anim';
import {C, FONT_SANS, FONT_SERIF_ITALIC} from '../theme';
import {Ribbon} from '../illustrations/Figures';

export const Scene8Resultats: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const b1 = range(frame, 100, 220);
  const b2 = range(frame, 300, 420);
  return (
    <SceneShell n={8} title="Les résultats" duration={duration}>
      <AbsoluteFill style={{fontFamily: FONT_SANS}}>
        <div style={{position: 'absolute', left: 100, top: 170, width: 860}}>
          <Reveal delay={20}><div style={{fontSize: 34, fontWeight: 600, color: C.gold, letterSpacing: 6}}>PLUS DE</div></Reveal>
          <Counter to={24000} delay={40} duration={140} size={250} color={C.white} />
          <Reveal delay={160}><div style={{fontSize: 44, fontWeight: 800, color: C.pink, letterSpacing: 2, marginTop: 8}}>DÉPISTAGES GRATUITS</div></Reveal>
          <div style={{marginTop: 34, height: 18, borderRadius: 9, background: 'rgba(255,255,255,.14)', overflow: 'hidden'}}>
            <div style={{width: `${b1 * 100}%`, height: '100%', background: `linear-gradient(90deg, ${C.pink}, #ff86c0)`}} />
          </div>
        </div>
        <div style={{position: 'absolute', left: 1020, top: 250, width: 800}}>
          <Counter to={4300} delay={240} duration={110} size={210} color={C.gold} />
          <Reveal delay={330}><div style={{fontSize: 40, fontWeight: 800, color: C.white, letterSpacing: 2, marginTop: 10, lineHeight: 1.2}}>LÉSIONS PRÉCANCÉREUSES<br />TRAITÉES</div></Reveal>
          <div style={{marginTop: 34, height: 18, borderRadius: 9, background: 'rgba(255,255,255,.14)', overflow: 'hidden'}}>
            <div style={{width: `${(4300 / 24000) * 100 * b2}%`, height: '100%', background: C.gold}} />
          </div>
        </div>
        <Reveal delay={460} y={30} style={{position: 'absolute', left: 100, right: 100, top: 800, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 36}}>
          <Ribbon size={96} />
          <div style={{fontFamily: FONT_SERIF_ITALIC, fontSize: 64, fontWeight: 600, color: C.white}}>« Autant de cancers potentiellement évités. »</div>
        </Reveal>
      </AbsoluteFill>
    </SceneShell>
  );
};
