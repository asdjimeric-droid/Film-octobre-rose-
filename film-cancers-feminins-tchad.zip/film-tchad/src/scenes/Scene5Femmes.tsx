import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {GraduationCap, Megaphone, ShieldCheck} from 'lucide-react';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {GlassCard, IconBadge} from '../components/ui';
import {range} from '../anim';
import {C} from '../theme';
import {ChadMap} from '../illustrations/Maps';
import {Ribbon} from '../illustrations/Figures';

export const Scene5Femmes: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const outline = range(frame, 0, 100);
  return (
    <SceneShell n={5} title="Aller vers les femmes" duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 90, top: 150}}>
          <ChadMap outline={outline} start={130} gap={50} height={870} />
        </div>
        <div style={{position: 'absolute', left: 1010, top: 170, width: 810}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
            <Reveal delay={20} bounce scale={0.5} y={0}><Ribbon size={110} /></Reveal>
            <AnimatedText text={"Octobre Rose,\nau plus près des femmes"} size={56} font="serif" accentWords={['Rose,']} delay={30} />
          </div>
          <Reveal delay={150} style={{marginTop: 30}}>
            <div style={{fontSize: 30, color: C.soft, lineHeight: 1.4}}>
              N'Djaména et six provinces : Hadjer-Lamis, Chari-Baguirmi, Ouaddaï, Logone Occidental, Logone Oriental et Mandoul.
            </div>
          </Reveal>
          <div style={{display: 'flex', flexDirection: 'column', gap: 20, marginTop: 40}}>
            {[
              {i: GraduationCap, t: 'Formation', d: 330},
              {i: Megaphone, t: 'Sensibilisation', d: 430},
              {i: ShieldCheck, t: 'Dépistage gratuit', d: 530},
            ].map(({i, t, d}) => (
              <Reveal key={t} delay={d} x={70} y={0}>
                <GlassCard style={{display: 'flex', alignItems: 'center', gap: 26, padding: '18px 28px'}}>
                  <IconBadge icon={i} size={88} />
                  <span style={{fontSize: 42, fontWeight: 700}}>{t}</span>
                </GlassCard>
              </Reveal>
            ))}
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
