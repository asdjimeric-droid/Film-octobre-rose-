import React from 'react';
import {Scene1Constat} from './Scene1Constat';
import {Scene2Reponse} from './Scene2Reponse';
import {Scene3Formatrices} from './Scene3Formatrices';
import {Scene4Demultiplier} from './Scene4Demultiplier';
import {Scene5Femmes} from './Scene5Femmes';
import {Scene6Nation} from './Scene6Nation';
import {Scene7Inclusion} from './Scene7Inclusion';
import {Scene8Resultats} from './Scene8Resultats';
import {Scene9Avenir} from './Scene9Avenir';
import {SceneFinal} from './SceneFinal';

export type SceneDef = {id: string; seconds: number; Component: React.FC<{duration: number}>};

// Somme des durées = 210 s (3 min 30).
export const SCENES: SceneDef[] = [
  {id: 'S1-Constat', seconds: 22, Component: Scene1Constat},
  {id: 'S2-Reponse', seconds: 20, Component: Scene2Reponse},
  {id: 'S3-Formatrices', seconds: 20, Component: Scene3Formatrices},
  {id: 'S4-Demultiplier', seconds: 20, Component: Scene4Demultiplier},
  {id: 'S5-Femmes', seconds: 24, Component: Scene5Femmes},
  {id: 'S6-Nation', seconds: 22, Component: Scene6Nation},
  {id: 'S7-Inclusion', seconds: 24, Component: Scene7Inclusion},
  {id: 'S8-Resultats', seconds: 20, Component: Scene8Resultats},
  {id: 'S9-Avenir', seconds: 22, Component: Scene9Avenir},
  {id: 'S10-Final', seconds: 16, Component: SceneFinal},
];
