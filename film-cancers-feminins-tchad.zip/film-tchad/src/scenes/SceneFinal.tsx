import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame} from 'remotion';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {range} from '../anim';
import {C, FONT_SANS, LOGOS} from '../theme';
import {Ribbon} from '../illustrations/Figures';

// Emplacement de logo : affiche le fichier officiel s'il est fourni, sinon un cadre réservé.
const LogoSlot: React.FC<{src: string | null; label: string}> = ({src, label}) => (
  <div style={{width: 470, height: 190, borderRadius: 24, background: src ? C.white : 'rgba(255,255,255,.05)', border: src ? 'none' : `2px dashed ${C.gold}`, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, textAlign: 'center'}}>
    {src ? <Img src={staticFile(src)} style={{maxWidth: '100%', maxHeight: '100%', objectFit: 'contain'}} /> : <span style={{fontFamily: FONT_SANS, fontSize: 24, color: C.soft, lineHeight: 1.35}}>Emplacement logo{'\n'}{label}</span>}
  </div>
);

export const SceneFinal: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const glow = 0.5 + Math.sin(frame / 25) * 0.1;
  return (
    <SceneShell n={10} title="Ensemble" duration={duration}>
      <AbsoluteFill>
        <AbsoluteFill style={{background: `radial-gradient(900px 600px at 50% 40%, rgba(232,62,140,${glow * 0.35}), transparent 70%)`}} />
        <Reveal delay={10} bounce scale={0.5} y={0} style={{position: 'absolute', left: 0, right: 0, top: 130, display: 'flex', justifyContent: 'center'}}>
          <Ribbon size={150} />
        </Reveal>
        <div style={{position: 'absolute', left: 0, right: 0, top: 320, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10}}>
          <AnimatedText text="Toute la nation se mobilise." size={96} font="serif" align="center" delay={30} />
          <AnimatedText text="Ensemble, sauvons des vies." size={96} font="serif" align="center" delay={110} color={C.pink} />
          <div style={{width: 260 * range(frame, 190, 250), height: 4, background: C.gold, marginTop: 22}} />
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 780, display: 'flex', justifyContent: 'center', gap: 80}}>
          <Reveal delay={230}><LogoSlot src={LOGOS.ministere} label={'Ministère de la Santé Publique\net de la Prévention'} /></Reveal>
          <Reveal delay={270}><LogoSlot src={LOGOS.pnlcc} label="PNLCC" /></Reveal>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
