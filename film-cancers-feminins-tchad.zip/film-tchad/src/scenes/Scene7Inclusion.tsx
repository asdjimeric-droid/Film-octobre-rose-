import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Accessibility, HeartPulse, Lock, ShieldCheck, Tent, Tractor} from 'lucide-react';
import {SceneShell} from '../components/SceneShell';
import {AnimatedText} from '../components/AnimatedText';
import {Reveal} from '../components/Reveal';
import {GlassCard} from '../components/ui';
import {C, FONT_SANS} from '../theme';
import {Woman, WOMEN_STYLES} from '../illustrations/Figures';

const CARDS = [
  {icon: HeartPulse, title: 'Femmes vivant avec le VIH', text: 'Risque six fois plus élevé de cancer du col de l\'utérus', hi: true},
  {icon: ShieldCheck, title: 'Professionnelles du sexe', text: 'Exposition accrue au HPV', hi: false},
  {icon: Accessibility, title: 'Femmes en situation de handicap', text: 'Un dépistage accessible à toutes', hi: false},
  {icon: Tent, title: 'Réfugiées et déplacées', text: 'Aller vers elles, là où elles se trouvent', hi: false},
  {icon: Tractor, title: 'Femmes rurales et nomades', text: 'Aucune femme laissée à l\'écart', hi: false},
  {icon: Lock, title: 'Femmes détenues', text: 'Le droit à la santé pour toutes', hi: false},
];

export const Scene7Inclusion: React.FC<{duration: number}> = ({duration}) => (
  <SceneShell n={7} title="Personne n'est laissé de côté" duration={duration}>
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 100, top: 150}}>
        <AnimatedText text="Personne n'est laissé de côté" size={70} font="serif" accentWords={['laissé']} />
      </div>
      {CARDS.map((c, i) => {
        const col = i % 3, row = Math.floor(i / 3);
        const Icon = c.icon;
        const st = WOMEN_STYLES[i];
        return (
          <Reveal key={i} delay={90 + i * 80} y={50} style={{position: 'absolute', left: 100 + col * 600, top: 310 + row * 335, width: 560}}>
            <GlassCard style={{height: 305, padding: 26, display: 'flex', gap: 26, alignItems: 'center', border: c.hi ? `2px solid ${C.pink}` : undefined}}>
              <div style={{position: 'relative', width: 170, height: 170, borderRadius: '50%', overflow: 'hidden', flex: 'none', background: 'rgba(255,255,255,.1)', border: `3px solid ${C.gold}`}}>
                <Woman size={300} skin={st.skin} wrap={st.wrap} dress={st.dress} accent={st.accent} style={{position: 'absolute', left: 10, top: 8}} />
              </div>
              <div style={{fontFamily: FONT_SANS}}>
                <Icon size={38} color={C.pink} />
                <div style={{fontSize: 29, fontWeight: 800, marginTop: 8, lineHeight: 1.2}}>{c.title}</div>
                <div style={{fontSize: 24, marginTop: 10, lineHeight: 1.3, color: c.hi ? '#FFB3D5' : C.soft, fontWeight: c.hi ? 700 : 400}}>{c.text}</div>
              </div>
            </GlassCard>
          </Reveal>
        );
      })}
    </AbsoluteFill>
  </SceneShell>
);
