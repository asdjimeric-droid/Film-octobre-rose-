import React from 'react';
import {C} from '../theme';

// Centre médical moderne (p = progression de construction 0..1).
export const Clinic: React.FC<{p?: number; width?: number}> = ({p = 1, width = 760}) => {
  const win = [[88, 190], [148, 190], [88, 262], [148, 262], [412, 190], [472, 190], [412, 262], [472, 262]];
  return (
    <svg viewBox="0 0 600 420" width={width} style={{overflow: 'visible'}}>
      <defs>
        <linearGradient id="glassC" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#CBEAFF" />
          <stop offset="1" stopColor="#6FB7E9" />
        </linearGradient>
      </defs>
      <ellipse cx="300" cy="396" rx="290" ry="16" fill="rgba(0,0,0,.28)" />
      <g style={{transformOrigin: '300px 392px', transform: `scaleY(${p})`}}>
        <rect x="60" y="130" width="480" height="262" rx="14" fill="#F4F7FA" />
        <rect x="60" y="130" width="480" height="34" rx="14" fill={C.pink} />
        <rect x="226" y="52" width="148" height="122" rx="10" fill={C.white} />
        <rect x="226" y="52" width="148" height="26" rx="10" fill={C.navy} />
        <rect x="289" y="92" width="22" height="58" fill={C.pink} />
        <rect x="271" y="110" width="58" height="22" fill={C.pink} />
        {win.map(([x, y], i) => (
          <rect key={i} x={x} y={y} width="46" height="54" rx="6" fill="url(#glassC)" stroke={C.navy2} strokeWidth="2" />
        ))}
        <rect x="250" y="288" width="100" height="104" rx="6" fill="url(#glassC)" stroke={C.navy} strokeWidth="3" />
        <line x1="300" y1="288" x2="300" y2="392" stroke={C.navy} strokeWidth="3" />
        <path d="M236 288 L364 288 L380 262 L220 262 Z" fill={C.pink} />
        <rect x="20" y="340" width="34" height="52" rx="6" fill="#2E8B6E" />
        <rect x="546" y="340" width="34" height="52" rx="6" fill="#2E8B6E" />
      </g>
    </svg>
  );
};

// Centre de cancérologie : tracé de conception puis remplissage (p = 0..1).
export const CancerCenter: React.FC<{p?: number; width?: number}> = ({p = 1, width = 860}) => {
  const draw = Math.min(1, p * 1.7);
  const fill = Math.max(0, Math.min(1, (p - 0.55) / 0.4));
  const outline = 'M70 440 L70 270 L250 270 L250 130 L450 130 L450 270 L630 270 L630 440 Z';
  const roof = 'M250 130 L350 62 L450 130';
  return (
    <svg viewBox="0 0 700 480" width={width} style={{overflow: 'visible'}}>
      <defs>
        <linearGradient id="glassK" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#D8F0FF" />
          <stop offset="1" stopColor="#5FA8DC" />
        </linearGradient>
      </defs>
      <ellipse cx="350" cy="446" rx="330" ry="16" fill="rgba(0,0,0,.28)" />
      <path d={outline} fill={C.white} opacity={fill * 0.96} />
      <path d={roof} fill={C.pink} opacity={fill} />
      {[[100, 300], [170, 300], [100, 370], [170, 370], [490, 300], [560, 300], [490, 370], [560, 370], [280, 160], [340, 160], [400, 160], [280, 230], [340, 230], [400, 230]].map(([x, y], i) => (
        <rect key={i} x={x} y={y} width="46" height="48" rx="5" fill="url(#glassK)" opacity={fill} />
      ))}
      <rect x="300" y="360" width="100" height="80" rx="6" fill={C.navy} opacity={fill} />
      <rect x="250" y="130" width="200" height="22" fill={C.navy} opacity={fill} />
      <text x="350" y="147" textAnchor="middle" fontSize="16" fontWeight="800" fill={C.gold} opacity={fill} letterSpacing="4">CNEC</text>
      <path d={outline} fill="none" stroke={C.gold} strokeWidth="3" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
      <path d={roof} fill="none" stroke={C.pink} strokeWidth="3" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
      <path d="M250 270 L450 270 M350 130 L350 270" stroke={C.gold} strokeWidth="2" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} opacity={1 - fill * 0.7} />
    </svg>
  );
};
