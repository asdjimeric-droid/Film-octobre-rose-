import React from 'react';
import {C, SKIN} from '../theme';

type FigureProps = {size?: number; skin?: string; style?: React.CSSProperties};

const Face: React.FC = () => (
  <>
    <ellipse cx="88" cy="112" rx="3" ry="3.6" fill="#1b1b1b" />
    <ellipse cx="112" cy="112" rx="3" ry="3.6" fill="#1b1b1b" />
    <path d="M90 129 Q100 137 110 129" stroke="#7a2b3a" strokeWidth="3" fill="none" strokeLinecap="round" />
  </>
);

// Femme tchadienne : foulard noué, tenue colorée, pagne en diagonale.
export const Woman: React.FC<FigureProps & {wrap?: string; dress?: string; accent?: string; armUp?: boolean}> = ({
  size = 300, skin = SKIN[0], wrap = C.pink, dress = C.white, accent = C.gold, armUp = false, style,
}) => (
  <svg viewBox="0 0 200 320" width={(size * 200) / 320} height={size} style={style}>
    <path d="M30 320 C30 250 50 205 100 195 C150 205 170 250 170 320 Z" fill={dress} />
    <path d="M58 320 C68 262 88 218 100 198 L116 320 Z" fill={accent} opacity=".92" />
    <circle cx="86" cy="270" r="4" fill={dress} opacity=".7" />
    <circle cx="98" cy="290" r="4" fill={dress} opacity=".7" />
    <path d="M42 235 C30 270 30 300 34 320" stroke={skin} strokeWidth="15" strokeLinecap="round" fill="none" />
    <path d={armUp ? 'M158 225 C186 200 190 160 178 120' : 'M162 235 C175 270 172 300 168 320'} stroke={skin} strokeWidth="15" strokeLinecap="round" fill="none" />
    <rect x="88" y="150" width="24" height="52" rx="10" fill={skin} />
    <ellipse cx="100" cy="112" rx="33" ry="40" fill={skin} />
    <path d="M65 108 C62 62 90 44 112 48 C140 54 140 90 136 108 C124 88 108 82 98 82 C84 82 72 92 65 108Z" fill={wrap} />
    <path d="M112 48 C128 26 158 34 150 60 C142 50 128 52 112 48Z" fill={wrap} />
    <circle cx="90" cy="64" r="3.5" fill={accent} />
    <circle cx="106" cy="60" r="3.5" fill={accent} />
    <circle cx="122" cy="70" r="3.5" fill={accent} />
    <circle cx="67" cy="128" r="4.5" fill={accent} />
    <Face />
  </svg>
);

// Professionnel de santé : blouse blanche, tenue, stéthoscope.
export const HealthPro: React.FC<FigureProps & {scrub?: string; male?: boolean; cap?: string}> = ({
  size = 300, skin = SKIN[1], scrub = C.pink, male = false, cap = '#FFFFFF', style,
}) => (
  <svg viewBox="0 0 200 320" width={(size * 200) / 320} height={size} style={style}>
    <path d="M24 320 C24 250 46 205 100 195 C154 205 176 250 176 320 Z" fill="#F4F7FA" stroke="#D3DDE8" strokeWidth="2" />
    <path d="M80 200 L100 252 L120 200 Z" fill={scrub} />
    <path d="M100 252 L100 320" stroke="#D3DDE8" strokeWidth="2" />
    <path d="M78 204 C66 262 106 278 114 246" stroke="#5B6B7A" strokeWidth="4" fill="none" strokeLinecap="round" />
    <circle cx="114" cy="244" r="7" fill={C.gold} />
    <rect x="132" y="250" width="24" height="12" rx="3" fill={C.white} stroke="#C2CFDC" />
    <rect x="136" y="254" width="12" height="3" fill={scrub} />
    <path d="M38 236 C26 270 26 300 30 320" stroke={skin} strokeWidth="15" strokeLinecap="round" fill="none" />
    <path d="M162 236 C174 270 174 300 170 320" stroke={skin} strokeWidth="15" strokeLinecap="round" fill="none" />
    <rect x="88" y="150" width="24" height="52" rx="10" fill={skin} />
    <ellipse cx="100" cy="112" rx="33" ry="40" fill={skin} />
    {male ? (
      <path d="M67 104 C66 66 86 60 100 60 C116 60 134 66 133 104 C124 86 112 80 100 80 C88 80 76 86 67 104Z" fill="#1d1612" />
    ) : (
      <>
        <path d="M65 108 C62 62 88 46 100 46 C114 46 138 62 135 108 C124 90 110 84 100 84 C88 84 74 92 65 108Z" fill={cap} stroke="#D3DDE8" strokeWidth="2" />
        <rect x="92" y="52" width="16" height="16" rx="3" fill={scrub} opacity=".0" />
      </>
    )}
    <Face />
  </svg>
);

export const Ribbon: React.FC<{size?: number; color?: string; style?: React.CSSProperties}> = ({size = 120, color = C.pink, style}) => (
  <svg viewBox="0 0 100 130" width={(size * 100) / 130} height={size} style={style}>
    <path fillRule="evenodd" fill={color} d="M50 8 C28 8 18 30 28 52 C34 66 44 76 50 84 C56 76 66 66 72 52 C82 30 72 8 50 8 Z M50 24 C41 24 37 35 42 46 L50 58 L58 46 C63 35 59 24 50 24 Z" />
    <path fill={color} d="M50 84 L26 124 L42 119 L50 104 Z" />
    <path fill={color} d="M50 84 L74 124 L58 119 L50 104 Z" />
  </svg>
);

// Boîte à images (outil de sensibilisation communautaire).
export const ImageBox: React.FC<{size?: number; style?: React.CSSProperties}> = ({size = 220, style}) => (
  <svg viewBox="0 0 220 200" width={size} height={(size * 200) / 220} style={style}>
    <rect x="28" y="96" width="164" height="96" rx="10" fill={C.gold} />
    <rect x="28" y="96" width="164" height="22" rx="10" fill="#B8932A" />
    <g transform="rotate(-6 70 80)">
      <rect x="46" y="20" width="62" height="86" rx="6" fill={C.white} />
      <circle cx="77" cy="50" r="14" fill={C.pink} />
      <rect x="60" y="72" width="34" height="8" rx="4" fill={C.navy2} />
    </g>
    <g transform="rotate(7 140 80)">
      <rect x="110" y="14" width="62" height="92" rx="6" fill="#FDF2F8" />
      <path d="M141 36 C128 36 124 50 132 60 L141 70 L150 60 C158 50 154 36 141 36Z" fill={C.pink} />
      <rect x="124" y="80" width="34" height="8" rx="4" fill={C.navy2} />
    </g>
  </svg>
);

export const WOMEN_STYLES = [
  {skin: SKIN[0], wrap: C.pink, dress: '#FFFFFF', accent: C.gold},
  {skin: SKIN[2], wrap: C.gold, dress: C.pink, accent: C.white},
  {skin: SKIN[3], wrap: '#2E8B6E', dress: '#F9D3E5', accent: C.gold},
  {skin: SKIN[1], wrap: C.navy2, dress: C.white, accent: C.pink},
  {skin: SKIN[4], wrap: '#C0392B', dress: '#FFF3D6', accent: C.navy},
  {skin: SKIN[0], wrap: '#7B3FA0', dress: C.white, accent: C.gold},
];
