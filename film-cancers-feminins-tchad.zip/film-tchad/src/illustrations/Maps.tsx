import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, FONT_SANS} from '../theme';

type Pt = [number, number];

/* ---------- Tchad (carte stylisée) ---------- */
const CHAD: Pt[] = [
  [15.99, 23.45], [23.98, 19.5], [24.0, 15.7], [22.9, 14.6], [22.4, 13.7], [22.0, 12.9], [22.5, 12.0], [22.4, 11.0],
  [22.9, 10.9], [22.0, 10.1], [21.8, 9.2], [20.5, 9.4], [19.2, 9.0], [18.6, 8.0], [16.6, 7.6], [15.5, 7.5], [14.6, 8.6],
  [14.5, 9.9], [15.2, 10.1], [15.0, 11.3], [14.2, 12.4], [14.0, 13.1], [13.6, 13.7], [13.5, 14.5], [15.0, 15.6],
  [15.2, 17.0], [14.9, 19.0], [15.6, 20.4], [15.0, 23.0],
];
const chadXY = (lon: number, lat: number): Pt => [(lon - 13.4) * 55 + 200, (23.6 - lat) * 55 + 25];
const toPath = (pts: Pt[]) => pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ') + ' Z';

export const PROVINCES = [
  {name: "N'Djaména", lon: 15.05, lat: 12.1, side: 'L', ly: 670, capital: true},
  {name: 'Hadjer-Lamis', lon: 15.3, lat: 12.9, side: 'L', ly: 585, capital: false},
  {name: 'Chari-Baguirmi', lon: 16.0, lat: 11.4, side: 'L', ly: 755, capital: false},
  {name: 'Logone Occidental', lon: 15.6, lat: 8.7, side: 'L', ly: 840, capital: false},
  {name: 'Logone Oriental', lon: 16.2, lat: 8.3, side: 'L', ly: 915, capital: false},
  {name: 'Mandoul', lon: 17.5, lat: 8.6, side: 'R', ly: 900, capital: false},
  {name: 'Ouaddaï', lon: 20.8, lat: 13.8, side: 'R', ly: 540, capital: false},
] as const;

export const ChadMap: React.FC<{outline: number; start: number; gap?: number; height?: number}> = ({outline, start, gap = 45, height = 860}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const d = toPath(CHAD.map(([lo, la]) => chadXY(lo, la)));
  return (
    <svg viewBox="0 0 1000 960" height={height} style={{overflow: 'visible'}}>
      <path d={d} fill="rgba(232,62,140,.14)" opacity={outline} />
      <path d={d} fill="none" stroke={C.gold} strokeWidth="3.5" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - outline} />
      {PROVINCES.map((pv, i) => {
        const s = spring({frame: frame - (start + i * gap), fps, config: {damping: 14}, durationInFrames: 34});
        const [x, y] = chadXY(pv.lon, pv.lat);
        const pillX = pv.side === 'L' ? 10 : pv.name === 'Ouaddaï' ? 800 : 690;
        const pillW = pv.side === 'L' ? 262 : pv.name === 'Ouaddaï' ? 180 : 170;
        const lx = pv.side === 'L' ? pillX + pillW : pillX;
        const pulse = 1 + (((frame + i * 12) % 60) / 60) * 2.2;
        return (
          <g key={pv.name} opacity={Math.min(1, s * 1.5)}>
            <line x1={lx} y1={pv.ly} x2={x} y2={y} stroke={C.gold} strokeWidth="2" strokeDasharray="6 6" opacity={0.8} />
            <circle cx={x} cy={y} r={(pv.capital ? 16 : 11) * pulse} fill="none" stroke={C.pink} strokeWidth="2" opacity={Math.max(0, 1 - (pulse - 1) / 2.2)} />
            <circle cx={x} cy={y} r={(pv.capital ? 16 : 11) * s} fill={pv.capital ? C.pink : C.white} stroke={C.gold} strokeWidth="3" />
            <g transform={`translate(${pillX} ${pv.ly - 24}) scale(${0.85 + 0.15 * s})`}>
              <rect width={pillW} height="48" rx="24" fill={pv.capital ? C.pink : C.navy2} stroke={C.gold} strokeWidth="2" />
              <text x={pillW / 2} y="31" textAnchor="middle" fontSize="23" fontWeight="700" fill={C.white} fontFamily={FONT_SANS}>{pv.name}</text>
            </g>
          </g>
        );
      })}
    </svg>
  );
};

/* ---------- Afrique (carte stylisée) ---------- */
const AFRICA: Pt[] = [
  [-5.9, 35.8], [-2, 35.1], [9.8, 37.3], [11, 33.3], [15, 32.3], [20, 32.1], [20, 30.9], [25, 31.6], [32, 31.2], [32.5, 29.9],
  [34.2, 26], [35.5, 23.9], [37.2, 21], [37.5, 18.5], [39.5, 15.5], [43, 12.5], [51, 11.8], [50.5, 9.5], [47, 4.5], [42, -1],
  [40.2, -3.5], [39.2, -7], [40.5, -11], [40.6, -15.5], [35, -20], [35.5, -24], [32.8, -26], [32.5, -28.5], [30, -31],
  [27, -33.5], [22, -34], [18.5, -34.2], [17.5, -30], [14.5, -23], [11.8, -17], [13.5, -10], [12.5, -5.5], [9.5, -1],
  [9.7, 3.9], [8, 4.5], [5, 5.8], [1, 6], [-3, 5], [-7.5, 4.4], [-11, 6.8], [-13.5, 9.5], [-15.5, 11.3], [-17.5, 14.7],
  [-16.5, 19.5], [-17, 21], [-13, 27.5], [-9.7, 30], [-9.8, 31.5], [-6.8, 34],
];
export const africaXY = (lon: number, lat: number): Pt => [(lon + 20) * 11.5 + 30, (38 - lat) * 11.5 + 30];

const route = (a: Pt, b: Pt, lift: number) => {
  const c: Pt = [(a[0] + b[0]) / 2, Math.min(a[1], b[1]) - lift];
  return {
    d: `M${a[0]} ${a[1]} Q${c[0]} ${c[1]} ${b[0]} ${b[1]}`,
    at: (t: number): Pt => [
      (1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * c[0] + t * t * b[0],
      (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * c[1] + t * t * b[1],
    ],
  };
};

export const AfricaMap: React.FC<{reveal: number; pBf: number; pSn: number; loop: number; width?: number}> = ({reveal, pBf, pSn, loop, width = 880}) => {
  const chad = africaXY(15, 12.5);
  const bf = africaXY(-1.5, 12.3);
  const sn = africaXY(-14.5, 14.5);
  const r1 = route(chad, bf, 110);
  const r2 = route(chad, sn, 210);
  const d = toPath(AFRICA.map(([lo, la]) => africaXY(lo, la)));
  const dot = (r: ReturnType<typeof route>, p: number, k: number) => {
    if (p < 1) return null;
    const [x, y] = r.at(((loop + k) % 1));
    return <circle cx={x} cy={y} r="8" fill={C.white} stroke={C.pink} strokeWidth="3" />;
  };
  const label = (p: Pt, text: string, dx: number, dy: number, on: boolean) => (
    <g opacity={on ? 1 : 0}>
      <rect x={p[0] + dx} y={p[1] + dy} width={text.length * 15 + 34} height="40" rx="20" fill={C.navy2} stroke={C.gold} strokeWidth="2" />
      <text x={p[0] + dx + (text.length * 15 + 34) / 2} y={p[1] + dy + 27} textAnchor="middle" fontSize="21" fontWeight="700" fill={C.white} fontFamily={FONT_SANS}>{text}</text>
    </g>
  );
  return (
    <svg viewBox="0 0 900 900" width={width} style={{overflow: 'visible'}}>
      <path d={d} fill="rgba(255,255,255,.07)" opacity={reveal} />
      <path d={d} fill="none" stroke={C.gold} strokeWidth="2.5" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - reveal} opacity=".8" />
      <path d={r1.d} fill="none" stroke={C.pink} strokeWidth="5" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - pBf} />
      <path d={r2.d} fill="none" stroke={C.gold} strokeWidth="5" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - pSn} />
      {dot(r1, pBf, 0)}
      {dot(r2, pSn, 0.5)}
      <circle cx={chad[0]} cy={chad[1]} r="15" fill={C.pink} stroke={C.white} strokeWidth="4" opacity={reveal} />
      <circle cx={bf[0]} cy={bf[1]} r="12" fill={C.white} stroke={C.pink} strokeWidth="4" opacity={pBf > 0.9 ? 1 : 0} />
      <circle cx={sn[0]} cy={sn[1]} r="12" fill={C.white} stroke={C.gold} strokeWidth="4" opacity={pSn > 0.9 ? 1 : 0} />
      {label(chad, 'Tchad', 24, -10, reveal > 0.9)}
      {label(bf, 'Burkina Faso', -60, 24, pBf > 0.9)}
      {label(sn, 'Sénégal', -50, 24, pSn > 0.9)}
    </svg>
  );
};
