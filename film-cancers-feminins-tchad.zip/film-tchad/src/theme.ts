import {loadFont as loadSans} from '@remotion/google-fonts/Montserrat';
import {loadFont as loadSerif} from '@remotion/google-fonts/PlayfairDisplay';

const sans = loadSans('normal', {weights: ['400', '600', '800'], subsets: ['latin', 'latin-ext']});
const serif = loadSerif('normal', {weights: ['600', '800'], subsets: ['latin', 'latin-ext']});
const serifItalic = loadSerif('italic', {weights: ['600'], subsets: ['latin', 'latin-ext']});

export const FONT_SANS = sans.fontFamily;
export const FONT_SERIF = serif.fontFamily;
export const FONT_SERIF_ITALIC = serifItalic.fontFamily;

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const C = {
  pink: '#E83E8C',
  navy: '#102A43',
  white: '#FFFFFF',
  gold: '#D4AF37',
  navy2: '#1B3F63',
  soft: '#CFD9E4',
};

export const SKIN = ['#5B3A29', '#6E4630', '#4A2E20', '#7B5037', '#8A5A3C'];

// Voix off + musique : déposer les fichiers dans public/audio puis passer enabled à true.
export const AUDIO = {
  voiceEnabled: true, // voix-off.mp3 fournie (84,5 s)
  voiceStartSeconds: 1, // décalage de départ de la voix off dans le film
  musicEnabled: true, // musique-fond.mp3 : composition originale générée (libre de droits)
  voiceOver: 'audio/voix-off.mp3',
  music: 'audio/musique-fond.mp3',
  musicVolume: 0.22,
};

// Logos OFFICIELS à fournir par le Ministère (chemins relatifs à /public).
export const LOGOS: {ministere: string | null; pnlcc: string | null} = {
  ministere: null,
  pnlcc: null,
};
