import React from 'react';
import {Composition, Folder} from 'remotion';
import {FPS, HEIGHT, WIDTH} from './theme';
import {SCENES} from './scenes';
import {MainVideo, TOTAL_FRAMES} from './MainVideo';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="MainVideo" component={MainVideo} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
    <Folder name="Scenes">
      {SCENES.map((s) => (
        <Composition
          key={s.id}
          id={s.id}
          component={s.Component}
          durationInFrames={s.seconds * FPS}
          fps={FPS}
          width={WIDTH}
          height={HEIGHT}
          defaultProps={{duration: s.seconds * FPS}}
        />
      ))}
    </Folder>
  </>
);
