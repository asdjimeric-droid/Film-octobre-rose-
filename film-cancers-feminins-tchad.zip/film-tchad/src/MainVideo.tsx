import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile} from 'remotion';
import {AUDIO, C, FPS} from './theme';
import {SCENES} from './scenes';
import {Wipe} from './components/Transitions';

export const TOTAL_FRAMES = SCENES.reduce((a, s) => a + s.seconds * FPS, 0); // 6300
const STARTS = SCENES.reduce<number[]>((acc, s, i) => {
  acc.push(i === 0 ? 0 : acc[i - 1] + SCENES[i - 1].seconds * FPS);
  return acc;
}, []);

export const MainVideo: React.FC = () => (
  <AbsoluteFill style={{background: C.navy}}>
    {SCENES.map((s, i) => {
      const Comp = s.Component;
      return (
        <Sequence key={s.id} from={STARTS[i]} durationInFrames={s.seconds * FPS} name={s.id}>
          <Comp duration={s.seconds * FPS} />
        </Sequence>
      );
    })}
    {SCENES.slice(1).map((s, i) => (
      <Sequence key={'t' + s.id} from={STARTS[i + 1] - 15} durationInFrames={30} name={'Transition ' + (i + 1)}>
        <Wipe variant={i} />
      </Sequence>
    ))}
    {AUDIO.voiceEnabled && (
      <Sequence from={Math.round(AUDIO.voiceStartSeconds * FPS)} name="Voix off">
        <Audio src={staticFile(AUDIO.voiceOver)} />
      </Sequence>
    )}
    {AUDIO.musicEnabled && (
        <Audio
          src={staticFile(AUDIO.music)}
          volume={(f) => interpolate(f, [0, 45, TOTAL_FRAMES - 90, TOTAL_FRAMES], [0, AUDIO.musicVolume, AUDIO.musicVolume, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
        />
    )}
  </AbsoluteFill>
);
